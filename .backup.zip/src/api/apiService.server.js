// Server-side API service for getStaticProps
import serverApiClient from '@/utils/axios.server';

// Home Page - Server-side versions
export const getHomeSEOAPI = async () => {
  const response = await serverApiClient.get('/api/v1/home/seo');
  return response?.data?.data;
};

export const getHomeTopNoticeAPI = async () => {
  const response = await serverApiClient.get('/api/v1/home/topNotice', { 
    headers: { 'Origin': process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000" } 
  });
  return response?.data?.data;
};

export const getHomeDashboardContentAPI = async () => {
  const response = await serverApiClient.get('/api/v1/home/dashboardContent', { 
    headers: { 'Origin': process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000" } 
  });
  return response?.data?.data;
};

export const getHomeCountriesAPI = async () => {
  const response = await serverApiClient.get('/api/v1/home/countries');
  return response?.data?.data;
};

export const getHomePartnersAPI = async () => {
  const response = await serverApiClient.get('/api/v1/home/partners', { 
    headers: { 'Origin': process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000" } 
  });
  return response?.data?.data;
};

export const getHomeSponsersAPI = async (params = {}) => {
  const response = await serverApiClient.get('/api/v1/home/sponsers', { 
    params, 
    headers: { 'Origin': process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000" } 
  });
  return response?.data?.data;
};

export const getPageCommonSettingsAPI = async () => {
  const response = await serverApiClient.get('/api/v1/page/commonSettings');
  return response?.data?.data;
};
